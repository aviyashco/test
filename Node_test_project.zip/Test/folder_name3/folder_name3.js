async function myFunc3(){
	let promise = Promise.resolve(1);
	  let result = await promise;
	  console.log(result)
  	console.log("Run main3.js file");
}

setTimeout(myFunc3, 3000);

module.exports = myFunc3;

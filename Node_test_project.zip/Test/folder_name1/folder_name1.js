function myFunc1(){
  console.log("Run main1.js file");
}

myFunc1();

module.exports = myFunc1;
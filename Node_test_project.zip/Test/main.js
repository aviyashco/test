//required modules for application

//express module
const express = require('express');

//create express instance
var app = express();

const http = require('http').Server(app);

//body parser module
const bodyParser   = require('body-parser');

//set access control header for receive CORS requests
app.use(function(req, res, next) {
	res.header('Access-Control-Allow-Origin', '*');
	next();
});

asyncCall();

async function asyncCall() {
  console.log('calling');
	try {
	 	const myFunc1 = await require('../folder_name1/folder_name1');
	 	let result = await myFunc1;
	    try{
	        const myFunc2 = await require('../folder_name2/folder_name2'); 
	        let main2result = await myFunc2;
	        try{
		        const myFunc3 = await require('../folder_name3/folder_name3'); 
				}
			catch (e) 
			  {
			    return 'err in folder3';
			  }
		   }
		catch (e) 
		  {
		    return 'err in folder2';
		  }
	} 
	catch (e) {
	return 'err in folder1';
	} 
 }
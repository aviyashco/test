function myFunc2(){

  const promiseA = new Promise( ( resolve, reject ) => {
    setTimeout( () => {
        resolve( 'result of main2.js file' );
    }, 1000 );
} );

promiseA
.then( ( result ) => {
    console.log( 'promiseA success:', result );
} )
.catch( ( error ) => {
    console.log( 'promiseA error:', error );
} )
.finally( () => {
    console.log('main2.js file is done!');
} );
}

setTimeout(myFunc2, 1500);

module.exports = myFunc2;


